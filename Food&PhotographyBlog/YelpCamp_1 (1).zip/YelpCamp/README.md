============================================
# From the RESTful Routing
*  INDEX	/dogs		GET		Display a list of all dogs
* NEW		/dogs/new	GET		Displays form to make a new dogs
* CREATE	/dogs		POST	Add new dog to DB
* SHOW	/dogs/:id	GET		Shows info about one dog

# For the Yelp project
* INDEX 	/foods
* NEW		/foods/new
* CREATE	/foods
* SHOW	/foods/:id

* NEW		/foods/:id/comments/new		GET
* CREATE	/foods/:id/comments			POST